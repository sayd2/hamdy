config = {
    'fedoracommunity.fedmsg.consumer.enabled': True,
}
